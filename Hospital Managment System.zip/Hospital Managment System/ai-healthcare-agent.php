<?php
include_once('hms/include/config.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>AI Healthcare Agent - HDIMS</title>
    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
    <style>
        .ai-agent-container {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px 0;
        }
        .ai-header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }
        .ai-header h1 {
            font-size: 3rem;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .ai-header p {
            font-size: 1.2rem;
            opacity: 0.9;
        }
        .chat-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            max-width: 800px;
            margin: 0 auto;
            height: 600px;
            display: flex;
            flex-direction: column;
        }
        .chat-header {
            background: linear-gradient(45deg, #4CAF50, #45a049);
            color: white;
            padding: 20px;
            text-align: center;
        }
        .chat-header h3 {
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f8f9fa;
        }
        .message {
            margin-bottom: 15px;
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }
        .message.user {
            flex-direction: row-reverse;
        }
        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: white;
            flex-shrink: 0;
        }
        .ai-avatar {
            background: linear-gradient(45deg, #4CAF50, #45a049);
        }
        .user-avatar {
            background: linear-gradient(45deg, #2196F3, #1976D2);
        }
        .message-content {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 18px;
            font-size: 14px;
            line-height: 1.4;
        }
        .message.ai .message-content {
            background: white;
            border: 1px solid #e0e0e0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .message.user .message-content {
            background: linear-gradient(45deg, #2196F3, #1976D2);
            color: white;
        }
        .chat-input-container {
            padding: 20px;
            background: white;
            border-top: 1px solid #e0e0e0;
        }
        .chat-input-wrapper {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .chat-input {
            flex: 1;
            padding: 12px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            outline: none;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .chat-input:focus {
            border-color: #4CAF50;
        }
        .send-btn {
            background: linear-gradient(45deg, #4CAF50, #45a049);
            color: white;
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .send-btn:hover {
            transform: scale(1.1);
        }
        .quick-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }
        .quick-btn {
            background: #f0f0f0;
            border: 1px solid #ddd;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .quick-btn:hover {
            background: #4CAF50;
            color: white;
            border-color: #4CAF50;
        }
        .typing-indicator {
            display: none;
            align-items: center;
            gap: 10px;
            color: #666;
            font-style: italic;
        }
        .typing-dots {
            display: flex;
            gap: 4px;
        }
        .typing-dots span {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #4CAF50;
            animation: typing 1.4s infinite;
        }
        .typing-dots span:nth-child(2) { animation-delay: 0.2s; }
        .typing-dots span:nth-child(3) { animation-delay: 0.4s; }
        
        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-10px); }
        }
        
        .back-to-home {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            transition: background 0.3s;
        }
        .back-to-home:hover {
            background: rgba(255,255,255,0.3);
            color: white;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="ai-agent-container">
        <a href="index.php" class="back-to-home">
            <i class="fas fa-arrow-left"></i> Back to Home
        </a>
        
        <div class="ai-header">
            <h1><i class="fas fa-robot"></i> AI Healthcare Agent</h1>
            <p>Your intelligent healthcare companion for 24/7 medical guidance</p>
        </div>
        
        <div class="chat-container">
            <div class="chat-header">
                <h3><i class="fas fa-stethoscope"></i> Dr. AI Assistant</h3>
                <small>Always here to help with your health concerns</small>
            </div>
            
            <div class="chat-messages" id="chatMessages">
                <div class="message ai">
                    <div class="message-avatar ai-avatar">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="message-content">
                        Hello! I'm your AI Healthcare Assistant. I can help you with:
                        <ul style="margin: 10px 0; padding-left: 20px;">
                            <li>General health information</li>
                            <li>Symptom analysis</li>
                            <li>Medication guidance</li>
                            <li>Emergency advice</li>
                            <li>Wellness tips</li>
                        </ul>
                        How can I assist you today?
                    </div>
                </div>
            </div>
            
            <div class="chat-input-container">
                <div class="chat-input-wrapper">
                    <input type="text" id="chatInput" class="chat-input" placeholder="Ask me about your health concerns..." maxlength="500">
                    <button class="send-btn" onclick="sendMessage()">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
                
                <div class="quick-actions">
                    <button class="quick-btn" onclick="askQuestion('What are the symptoms of common cold?')">Common Cold</button>
                    <button class="quick-btn" onclick="askQuestion('How to manage stress?')">Stress Management</button>
                    <button class="quick-btn" onclick="askQuestion('What should I do in case of emergency?')">Emergency</button>
                    <button class="quick-btn" onclick="askQuestion('Healthy diet recommendations')">Healthy Diet</button>
                    <button class="quick-btn" onclick="askQuestion('Exercise benefits')">Exercise</button>
                </div>
                
                <div class="typing-indicator" id="typingIndicator">
                    <i class="fas fa-robot"></i>
                    <span>Dr. AI is typing</span>
                    <div class="typing-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script>
        const aiResponses = {
            'common cold': 'Common cold symptoms include runny nose, sore throat, cough, sneezing, and mild fever. Rest, stay hydrated, and consider over-the-counter remedies. If symptoms persist or worsen, consult a healthcare professional.',
            'stress': 'To manage stress: practice deep breathing, regular exercise, maintain a healthy diet, get adequate sleep, try meditation or yoga, and consider talking to a counselor. Remember, it\'s okay to take breaks.',
            'emergency': 'In a medical emergency, call emergency services immediately. While waiting, stay calm, follow any specific instructions given, and do not move the person unless absolutely necessary for safety.',
            'diet': 'A healthy diet includes: fruits and vegetables, whole grains, lean proteins, healthy fats, and plenty of water. Limit processed foods, sugar, and excessive salt. Consult a nutritionist for personalized advice.',
            'exercise': 'Regular exercise benefits include improved cardiovascular health, stronger muscles and bones, better mental health, weight management, and increased energy. Aim for at least 150 minutes of moderate activity weekly.',
            'default': 'I understand you\'re asking about healthcare. While I can provide general health information, please remember that I cannot replace professional medical advice. For specific medical concerns, please consult with a qualified healthcare provider. Is there a particular health topic you\'d like to know more about?'
        };

        function addMessage(content, isUser = false) {
            const chatMessages = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${isUser ? 'user' : 'ai'}`;
            
            const avatarDiv = document.createElement('div');
            avatarDiv.className = `message-avatar ${isUser ? 'user-avatar' : 'ai-avatar'}`;
            avatarDiv.innerHTML = `<i class="fas ${isUser ? 'fa-user' : 'fa-robot'}"></i>`;
            
            const contentDiv = document.createElement('div');
            contentDiv.className = 'message-content';
            contentDiv.textContent = content;
            
            messageDiv.appendChild(avatarDiv);
            messageDiv.appendChild(contentDiv);
            chatMessages.appendChild(messageDiv);
            
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        function showTyping() {
            document.getElementById('typingIndicator').style.display = 'flex';
        }

        function hideTyping() {
            document.getElementById('typingIndicator').style.display = 'none';
        }

        function getAIResponse(userMessage) {
            const message = userMessage.toLowerCase();
            
            // Check for specific keywords
            for (const [keyword, response] of Object.entries(aiResponses)) {
                if (message.includes(keyword)) {
                    return response;
                }
            }
            
            // Check for emergency keywords
            if (message.includes('emergency') || message.includes('urgent') || message.includes('severe')) {
                return 'This sounds like it might be a medical emergency. Please call emergency services immediately or go to the nearest emergency room. Your safety is the top priority.';
            }
            
            // Check for medication keywords
            if (message.includes('medication') || message.includes('medicine') || message.includes('drug')) {
                return 'For medication-related questions, please consult with your doctor or pharmacist. They can provide specific guidance based on your medical history and current medications. Never change your medication regimen without professional advice.';
            }
            
            // Check for appointment keywords
            if (message.includes('appointment') || message.includes('book') || message.includes('schedule')) {
                return 'To book an appointment with our healthcare providers, please use our online booking system or call our clinic directly. You can also visit our main page to access the patient portal.';
            }
            
            return aiResponses.default;
        }

        function sendMessage() {
            const input = document.getElementById('chatInput');
            const message = input.value.trim();
            
            if (message === '') return;
            
            // Add user message
            addMessage(message, true);
            input.value = '';
            
            // Show typing indicator
            showTyping();
            
            // Simulate AI response delay
            setTimeout(() => {
                hideTyping();
                const response = getAIResponse(message);
                addMessage(response);
            }, 1500 + Math.random() * 1000);
        }

        function askQuestion(question) {
            document.getElementById('chatInput').value = question;
            sendMessage();
        }

        // Allow sending message with Enter key
        document.getElementById('chatInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });

        // Auto-focus on input
        document.getElementById('chatInput').focus();
    </script>
</body>
</html>

