// Import Hedera SDK and dotenv
import { Client, AccountId, PrivateKey, Hbar, TransferTransaction } from "@hashgraph/sdk";
import dotenv from "dotenv";
dotenv.config();

// Load credentials from .env file
const myAccountId = AccountId.fromString(process.env.MY_ACCOUNT_ID);
const myPrivateKey = PrivateKey.fromString(process.env.MY_PRIVATE_KEY);

// Connect to Hedera Testnet
const client = Client.forTestnet().setOperator(myAccountId, myPrivateKey);

// Example: record a transaction when appointment is booked
async function logAppointment(patientId, doctorId) {
    const transaction = await new TransferTransaction()
        .addHbarTransfer(myAccountId, new Hbar(-0.0001)) // send small amount
        .addHbarTransfer("0.0.12345", new Hbar(0.0001))   // receiver (example)
        .execute(client);

    const receipt = await transaction.getReceipt(client);
    console.log(✅ Appointment recorded for patient ${patientId} with doctor ${doctorId}. Status: ${receipt.status});
}

logAppointment("P-1001", "D-2025");