// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract HospitalAppointments {
    struct Appointment {
        uint id;
        address patient;
        string doctorName;
        string date;
        bool confirmed;
    }

    uint public appointmentCount = 0;
    mapping(uint => Appointment) public appointments;

    event AppointmentBooked(uint id, address patient, string doctorName, string date);
    event AppointmentConfirmed(uint id, string doctorName);

    // Book appointment
    function bookAppointment(string memory _doctorName, string memory _date) public {
        appointmentCount++;
        appointments[appointmentCount] = Appointment(
            appointmentCount,
            msg.sender,
            _doctorName,
            _date,
            false
        );
        emit AppointmentBooked(appointmentCount, msg.sender, _doctorName, _date);
    }

    // Doctor confirms appointment
    function confirmAppointment(uint _id) public {
        Appointment storage appt = appointments[_id];
        require(appt.id != 0, "Appointment does not exist");
        appt.confirmed = true;
        emit AppointmentConfirmed(_id, appt.doctorName);
    }

    // Get appointment details
    function getAppointment(uint _id) public view returns (
        uint, address, string memory, string memory, bool
    ) {
        Appointment memory appt = appointments[_id];
        return (appt.id, appt.patient, appt.doctorName, appt.date, appt.confirmed);
    }
}
